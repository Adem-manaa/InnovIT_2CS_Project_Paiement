import 'package:flutter/material.dart';

const Color coffeeBrown = Color(0xffB48454);
const Color deepGreen = Color(0xff04542C);
const Color coffeeBeige = Color(0xffE4C49C);