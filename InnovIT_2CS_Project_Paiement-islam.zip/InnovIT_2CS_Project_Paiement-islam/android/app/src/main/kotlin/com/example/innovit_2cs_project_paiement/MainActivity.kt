package com.example.innovit_2cs_project_paiement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
